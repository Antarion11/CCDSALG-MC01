#include "point.h"

Point findAnchorPoint(Point points[], int n) {
    Point anchor = points[0];
    for (int i = 1; i < n; i++) {
        if (points[i].y < anchor.y || (points[i].y == anchor.y && points[i].x < anchor.x)) {
            anchor = points[i];
        }
    }
    return anchor;
}

double calculateCrossProduct(Point anchor, Point p1, Point p2) {
    return (p1.x - anchor.x) * (p2.y - anchor.y) - (p1.y - anchor.y) * (p2.x - anchor.x);
}

int comparePolar(Point anchor, Point p1, Point p2) {
    double cross = calculateCrossProduct(anchor, p1, p2);
    if (cross > 0) return -1;
    if (cross < 0) return 1;
    return 0;
}
