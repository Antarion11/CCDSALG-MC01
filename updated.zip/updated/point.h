#ifndef POINT_H
#define POINT_H

typedef struct {
    double x;
    double y;
} Point;

// Function declarations only
Point findAnchorPoint(Point points[], int n);
double calculateCrossProduct(Point anchor, Point p1, Point p2);
int comparePolar(Point anchor, Point p1, Point p2);

#endif // POINT_H
