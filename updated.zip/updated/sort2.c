#include "sort2.h"

// Selection sort implementation for sorting points by polar angle
void selectionSort(Point points[], int n, Point anchor) {
    for (int i = 0; i < n - 1; i++) {
        int minIdx = i;
        for (int j = i + 1; j < n; j++) {
            if (comparePolar(anchor, points[j], points[minIdx]) < 0) {
                minIdx = j;
            }
        }
        // Swap points[i] and points[minIdx]
        Point temp = points[i];
        points[i] = points[minIdx];
        points[minIdx] = temp;
    }
}

// Partition function for Quick Sort
int partition(Point points[], int low, int high, Point anchor) {
    Point pivot = points[high];
    int i = low - 1;
    for (int j = low; j < high; j++) {
        if (comparePolar(anchor, points[j], pivot) < 0) {
            i++;
            // Swap points[i] and points[j]
            Point temp = points[i];
            points[i] = points[j];
            points[j] = temp;
        }
    }
    // Swap points[i+1] and points[high] (pivot)
    Point temp = points[i + 1];
    points[i + 1] = points[high];
    points[high] = temp;
    return i + 1;
}

// Quick sort implementation for sorting points by polar angle
void quickSort(Point points[], int low, int high, Point anchor) {
    if (low < high) {
        int pi = partition(points, low, high, anchor);
        quickSort(points, low, pi - 1, anchor);
        quickSort(points, pi + 1, high, anchor);
    }
}
