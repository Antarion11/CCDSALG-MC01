#ifndef SORT_H
#define SORT_H

#include "point.h"

// Selection sort function for sorting points by polar angle
void selectionSort(Point points[], int n, Point anchor);

// Quick sort function for sorting points by polar angle
void quickSort(Point points[], int low, int high, Point anchor);

#endif
