#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <stdbool.h>
#include "point.h"
#include "stack.h"
#include "sort.h"

Stack grahamScanQuick(Point points[], int n, int *hullSize);

int main() {
    // Ask for input and output file names
    char inputFile[100], outputFile[100];
    printf("Enter the input filename: ");
    scanf("%s", inputFile);
    printf("Enter the output filename: ");
    scanf("%s", outputFile);

    // Open the input file
    FILE *input = fopen(inputFile, "r");
    if (!input) {
        fprintf(stderr, "Error: Could not open input file %s\n", inputFile);
        return 1;
    }
    printf("Input file %s opened successfully.\n", inputFile);

    // Read the number of points
    int n;
    fscanf(input, "%d", &n);
    if (n < 3) {
        fprintf(stderr, "Error: Number of points must be at least 3.\n");
        fclose(input);
        return 1;
    }

    // Read points from file
    Point points[n];
    for (int i = 0; i < n; i++) {
        fscanf(input, "%lf %lf", &points[i].x, &points[i].y);
    }
    fclose(input);

    // Measure elapsed time for Graham's Scan with Quick Sort
    clock_t start, end;
    start = clock();  // Start timing

    // Run Graham's Scan using Quick 
    int hullSize;
    Stack hull = grahamScanQuick(points, n, &hullSize);

    end = clock();  // End timing
    double time_taken = ((double)(end - start)) * 1000.0 / CLOCKS_PER_SEC; // Convert to milliseconds
    printf("Elapsed time (Quick Sort): %.2f ms\n", time_taken);

    // Open the output file
    FILE *output = fopen(outputFile, "w");
    if (!output) {
        fprintf(stderr, "Error: Could not open output file %s\n", outputFile);
        return 1;
    }

    // Write the number of points in the convex hull
    fprintf(output, "%d\n", hullSize);

    Point hullPoints[hullSize];
    int index = 0;

    // Pop points off the stack and store them in an array to reverse the order
    while (!ISEMPTY(&hull)) {
        hullPoints[index++] = POP(&hull);
    }

    // Print the points in counterclockwise order as derived
    for (int i = hullSize - 1; i >= 0; i--) {
        fprintf(output, "%.2f %.2f\n", hullPoints[i].x, hullPoints[i].y);
    }

    fclose(output);
    printf("Convex hull written to %s\n", outputFile);
    return 0;
}


