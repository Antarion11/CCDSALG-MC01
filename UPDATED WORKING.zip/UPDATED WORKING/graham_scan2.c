#include <stdio.h>
#include "point.h"
#include "stack.h"  // Stack utilities
#include "sort.h"   // Sorting utilities

// Graham's Scan using Quick Sort
Stack grahamScanQuick(Point points[], int n, int *hullSize) {
    Stack stack;
    CREATE(&stack);                      // Initialize the stack
    Point anchor = findAnchorPoint(points, n); // Find the anchor point

    // Sort the points based on polar angle using Quick Sort
    quickSort(points, 0, n - 1, anchor);

    // Push the first two points onto the stack (start with anchor and first sorted point)
    PUSH(&stack, anchor);
    PUSH(&stack, points[1]);

    // Process remaining points, ensuring left turns
    for (int i = 2; i < n; i++) {
        // Remove points from the stack if they make a right turn or are collinear
        while (stack.size >= 2 && calculateCrossProduct(NEXT_TO_TOP(&stack), TOP(&stack), points[i]) <= 0) {
            POP(&stack);
        }
        PUSH(&stack, points[i]);
    }

    // If the last point is the same as the starting point, remove it to avoid duplicates
    if (stack.size > 1 && TOP(&stack).x == anchor.x && TOP(&stack).y == anchor.y) {
        POP(&stack);
    }

    // Store the final hull size
    *hullSize = stack.size;

    return stack;
}
